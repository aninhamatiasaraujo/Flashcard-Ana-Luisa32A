import React from "react";
import { Row } from 'react-materialize';
import { NavLink} from 'react-router-dom'

import Curso_card from "./course";


const Courses = (props) => {
  return (
    <div>
      <Row>
        <div class="row">
          <div class="rowc">
            <h5>Courses</h5>
            <NavLink to="/formulario">
              <a class="btn-floating btn-large waves-effect waves-light red">
                <i class="material-icons">add</i>
              </a>
            </NavLink>
          </div>
            {props.coursesData.map(course => (
              <Curso_card 
                course={course} />
            ))}
          </div>
      </Row>
    </div>
  )
};

export default Courses;