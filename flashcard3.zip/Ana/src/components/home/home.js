import React from "react";
import { Row, Col, Card } from 'react-materialize';

const Home = () => ( 
  <Row>
    <Col m={11} s={11}>
        <h5 className="subtitle">Sobre nosso site</h5>
        <Card>
          <div>
            <p><b>Objetivo</b></p>
            <p>O objetivo desse site é auxiliar os alunos que desejam aprimorar seus conhecimentos em determinadas matérias que tenham dificuldade, ajudando na fixação da matéria para provas e vestibulares nas quais o aluno queira participar.</p>
            <br/>
            <p><b>Método</b></p>
            <p>Para realizar essa tarefa, escolhemos o uso de Flashcards, um método que facilita o aprendizado do estudante, fazendo com que o mesmo grave os assuntos com mais facilmente e se desenvolva melhor.</p>
            <br/>
            <p><b>Convite</b></p>
            <p>Agora convidamos você para experimentar, testar e avaliar nosso sistema de cursos preparatórios com Flashcards. Esperamos que goste.</p>
          </div>
        </Card>
    </Col>
  </Row>
);

export default Home;